import unittest
import Question_one

class MyReducespace(unittest.TestCase):
    def test_reducespace(self):
        result=Question_one.reducespace("tytyt    ytyty   GHGHG")
        self.assertEqual(result,"tytyt ytyty GHGHG")


    def test_reducespaces(self):
        result = Question_one.reducespace("tytyt      GHGHG hjhjhhjhjhjh           jkkjkjkjk nmnm       mnmnm")
        self.assertEqual(result, "tytyt GHGHG hjhjhhjhjhjh jkkjkjkjk nmnm mnmnm")


if __name__ == '__main__':
    unittest.main()
