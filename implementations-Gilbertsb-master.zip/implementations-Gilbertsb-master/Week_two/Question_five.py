def nntimes(n): #function to find n ntimes
    lis_to_hold_number=[]#list to hold element
    for i in range(1, n+1):#outer loop
        for j in range(i):#inner loop
            lis_to_hold_number.append(i)#appending element in list
    print(lis_to_hold_number)
    return lis_to_hold_number
nntimes(4)


###################################
#time complextity is O(n^2) as we will have to use two loops, and select from list
#Space complexty is constant O(1) since we have one list
##################################