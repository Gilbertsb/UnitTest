def reducespace(strin):# Method to reduce spaces in text

    for i in range(len(strin)):# loop inside sring
        if strin.find(chr(32)*2)>0: # condition that is checking if there is multple spaces
                strin = strin.replace(chr(32)*2,chr(32)) #replacing multple spaces with single space

    return strin

print(reducespace("Gilbert    SIBOMANA"))

###################################
#time complextity is O(n) as we will have to search through the string
#Space complexty is constant O(1)
##################################