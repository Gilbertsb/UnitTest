def combinelists(list):#function to combine list into one list
    list2 = []  #list to hold elements
    for j in list: #loop through list(outer)
        for item in j: #(in loop to help us to append)
            if item not in list2: # check if item is not i the list
                list2.append(item)  # appending element in a list


    return list2
print(combinelists([[10,13,17],[3,5,1],[13,11,12],[1,3,4,5,6,7,8,9]]))


###################################
#time complextity is O(n^2) as we will have to use two loops, and select from list
#Space complexty is constant O(1)
##################################