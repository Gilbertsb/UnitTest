from collections import Counter #Importing counter
def countstring(string):#function to count string
   decionaly_to_elements={}#dictionaly to hold element
   occur_count = Counter(string) # get dictionary with letters as key and occurrence as value
   for key in occur_count.keys():
      decionaly_to_elements[key]=str(occur_count.get(key)) #adding key and values to a dictonaly
   print(decionaly_to_elements)
   return decionaly_to_elements

countstring("Gilbert")

###################################
#time complextity is O(n) as we will have to search throu the string
#Space complexty is constant O(1)
##################################