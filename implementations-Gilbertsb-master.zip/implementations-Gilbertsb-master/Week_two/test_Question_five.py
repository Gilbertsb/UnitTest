import unittest
import Question_five

class ntimes(unittest.TestCase):
    def test_finddifference(self):
        self.assertListEqual(Question_five.nntimes(5), ([1, 2, 2, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 5]))

    def test_finddifference_negative(self):
        self.assertListEqual(Question_five.nntimes(-5), ([]))

    def test_finddifference_zoro(self):
        self.assertListEqual(Question_five.nntimes(0), ([]))

    def test_finddifference_one(self):
        self.assertListEqual(Question_five.nntimes(1), ([1]))


if __name__ == '__main__':
    unittest.main()









