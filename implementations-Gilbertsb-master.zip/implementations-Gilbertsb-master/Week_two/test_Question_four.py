import unittest
import Question_four

class Find_difference(unittest.TestCase):
    def test_finddifference(self):
        self.assertEqual(Question_four.findthedifference([4, 5, 6, -3], [4, 5, 6]), -3)




if __name__ == '__main__':
    unittest.main()




