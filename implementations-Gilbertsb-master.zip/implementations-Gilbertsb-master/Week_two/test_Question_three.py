import unittest
import Question_three


class Combine_list(unittest.TestCase):
    def test_combinelist(self):
        self.assertListEqual(Question_three.combinelists([[13, 11, 12], [1, 3, 4, 5, 6, 7, 8, 9]]), ([13, 11, 12, 1, 3, 4, 5, 6, 7, 8, 9]))

    def test_combinelist_oneempty(self):
        self.assertListEqual(Question_three.combinelists([[13, 11, 12], []]),
                             ([13, 11, 12]))

    def test_combinelist_all_list_empty(self):
        self.assertListEqual(Question_three.combinelists([[], [], [], []]), ([]))



if __name__ == '__main__':
    unittest.main()
