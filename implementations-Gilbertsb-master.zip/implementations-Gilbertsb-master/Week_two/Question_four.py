
def findthedifference(arr1,arr2):#Function to find difference between 2 lists
    n=0
    differentiate=set(arr1)-set(arr2)#differentiating list with help of set()
    for i in differentiate:#looping through set
        print(i, end=" ") #printing element of set
        n=i
    return n

findthedifference([-2,4,5,6,7,-3,8],[4,5,6])


###################################
#time complextity is O(n) as we will have to go through the set
#Space complexty is O(1+n)
##################################