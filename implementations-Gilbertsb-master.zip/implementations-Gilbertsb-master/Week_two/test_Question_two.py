import unittest
import Question_two


class Countstring(unittest.TestCase):
    def test_countstring(self):
        self.assertDictEqual((Question_two.countstring("Gilly Gilbert")), ({'G': '2', 'i': '2', 'l': '3', 'y': '1', ' ': '1', 'b': '1', 'e': '1', 'r': '1', 't': '1'}))
    #
    def test_countstring_space(self):
        self.assertDictEqual((Question_two.countstring(" ")), ({' ': '1'}))

    def test_countstring_empty(self):
        self.assertDictEqual((Question_two.countstring("")), ({}))

if __name__ == '__main__':
    unittest.main()
