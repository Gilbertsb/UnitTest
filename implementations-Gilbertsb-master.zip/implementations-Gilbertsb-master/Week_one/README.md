# implementations-Gilbertsb

This repository is made of 3 Algorithm; one Find maximum number in any list, another sort numbers, and anothoer one convert lowercase letters into upper case letters 
for all of them they show time used to excute and memory used.

To use them you may need Pyhton 3
With some modules which are; Random,memory_profile,numpy,time,string
