import unittest
import Question2


class MyTestCase(unittest.TestCase):
    def test_del_e(self):
        test = Question2.Array.del_e()
        self.assertListEqual(test, [12, 3, 4, 5, 56, 7, 8, 78, 9, 71, 23, 2])

    def test_add(self):
        test = Question2.Array.add(90)
        self.assertListEqual(test, [12, 3, 4, 5, 56, 7, 8, 78, 9, 71, 23, 2, 90])



if __name__ == '__main__':
    unittest.main()
