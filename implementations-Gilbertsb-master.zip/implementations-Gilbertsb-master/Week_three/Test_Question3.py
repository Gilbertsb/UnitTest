import unittest
import Question3


class MyTestCase(unittest.TestCase):
    def test_contain(self):
        test = Question3.ar.contain([12, 3, 4, 5, 56, 7, 8, 78, 9, 71, 23, 2],12)
        self.assertTrue(test,True)

    def test_contain1(self):
        test = Question3.ar.contain([5,8,4,0],7)
        self.assertFalse(test,False)

    def test_reverse(self):
        test = Question3.ar.reverse([12, 3, 4, 5, 56, 7, 8, 78, 9, 71, 23, 2, 90])
        self.assertListEqual(test, [90, 2, 23, 71, 9, 78, 8, 7, 56, 5, 4, 3, 12])

    def test_insert(self):
        test = Question3.ar.insert([5,8,5,4],78,3)
        self.assertListEqual(test,[5, 8, 5, 78])

    def test_insert1(self):
        test = Question3.ar.insert([5,8,5,4],78,3)
        self.assertListEqual(test,[5, 8, 5,78])


if __name__ == '__main__':
    unittest.main()
