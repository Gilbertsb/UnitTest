import unittest
import Question1

class MyTestCase(unittest.TestCase):
    def test_len(self):
        test = Question1.a.len()
        self.assertEqual(test, 15)

    def test_get(self):
        test = Question1.a.get(2)
        self.assertEqual(test, 4)

    def test_set(self):
        test = Question1.a.set(89,3)
        self.assertListEqual(test,[12, 3, 4, 89, 6, 6, 7, 8, 9, 0, 3, 4, 6, 7, 8])

if __name__ == '__main__':
    unittest.main()
