import unittest
import Question4


class MyTestCase(unittest.TestCase):
    def test_add(self):
        test = Question4.associa.add("name",1)
        self.assertDictEqual(test,{'name': 1})

    def test_lookup(self):
        test = Question4.associa.lookup("name")
        self.assertTrue(test,True)

    def test_lookup1(self):
        test = Question4.associa.lookup("age")
        self.assertFalse(test,False)

    def test_remove(self):
        test = Question4.associa.remove("name")
        self.assertDictEqual(test,{})

    def test_modify(self):
        test = Question4.associa.modify("name",4)
        self.assertDictEqual(test,{'name': 4})


if __name__ == '__main__':
    unittest.main()
