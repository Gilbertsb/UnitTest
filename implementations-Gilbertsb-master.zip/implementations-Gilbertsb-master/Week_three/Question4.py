class associate():
    associative={}
    def add(self,key, value):
        if key not in self.associative:
            self.associative[key] = value
        return self.associative

    def remove(self,key):
               del self.associative[key]
               return self.associative
    def modify(self,key, newvalue):
        self.associative[key]=newvalue
        return self.associative
    def lookup(self,key):
        if key in self.associative:
            return True
        else:
            return False


#For all methods in this class, time complexity is O(1) And space complexty is O(1)



associa=associate()


