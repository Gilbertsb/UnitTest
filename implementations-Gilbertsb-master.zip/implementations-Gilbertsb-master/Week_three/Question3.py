
class arr():

    def contain(self,arry,val):
        if val in arry:
            return True
        else:
            return False

    def reverse(self,Arr):
        Newarr = Arr[::-1]
        return Newarr
    def insert(self,arr,val,ind):
        arr[ind] = val
        return arr


ar=arr()

#for contain the time complexity is O(n)
#for reverser time complexity is O(1)
#For insert the time complexity O(1)

#And Space complexity is O(1) for all method