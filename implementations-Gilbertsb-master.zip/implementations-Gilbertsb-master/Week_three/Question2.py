
class dynamic_arr():
    def __init__(self):
        self.Arr=[12,3,4,5,56,7,8,78,9,71,23,2]

    def add(self,val):
        self.Arr.append(val)
        return self.Arr

    def del_e(self):
        self.Arr.pop()
        return self.Arr


Array=dynamic_arr()

#For all method time complexity is O(1) and space complexity is O(1)