
class dy_Array():
    def __init__(self):
        self.Arr = [12, 3, 4, 5, 6, 6, 7, 8, 9, 0, 3, 4, 6, 7, 8]

    # len method
    def len(self):

        count = 0
        for i in self.Arr:
            count=count+1
        return count

    def get(self,index):
        specified_num=0
        for j in range(len(self.Arr)):
            if(self.Arr[j]==self.Arr[index]):
                specified_num=self.Arr[j]
        return specified_num

    def set(self,val,index):
        self.Arr[index]=val
        return self.Arr




# Object creation
a = dy_Array()

#for len() and get() method Time complexity is O(n)
#And for set time complexity is O(1)

#Space complexity is O(1) for all