import unittest
import Question3


class MyTestCase(unittest.TestCase):
    def test_GetMinimum(self):
        test = Question3.run.GetMinimum()
        self.assertEqual(test,9)

    def test_ExtractMinimum(self):
        test = Question3.run.ExtractMinimum()
        self.assertEqual(test,None)

    def test_insert(self):
        test = Question3.run.insert(4)
        self.assertEqual(test, None)

    def test_Delete(self):
        test = Question3.run.Delete(0)
        self.assertEqual(test, 3)


if __name__ == '__main__':
    unittest.main()
