def check_minheap(arr):
    n=len(arr)
    for i in range(int((n - 2) / 2) + 1):
        if (arr[i] > arr[2 * i + 1] or ((2 * i + 2 !=n)and arr[i] > arr[2 * i + 2])):
            return False

        return True



#the time complexty is O(n) and auxlially space is O(1)