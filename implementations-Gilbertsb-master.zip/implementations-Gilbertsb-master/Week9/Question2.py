def heapify(arr, n, i):
    smallest = i # Initialize smallest as root
    left = 2 * i + 1 # left = 2*i + 1
    right = 2 * i + 2  # right = 2*i + 2

    # If left child is smaller than root
    if (left < n and arr[left] < arr[smallest]):
        smallest = left

        # If right child is smaller than smallest so far
    if (right < n and arr[right] < arr[smallest]):
        smallest = right

        # If smallest is not root
    if (smallest != i):
        swap = arr[i]
        arr[i] = arr[smallest]
        arr[smallest] = swap

        # Recursively heapify the sub tree
        heapify(arr, n, smallest)

def create_Heap(arr):
    n=len(arr)
    # Index of last non-leaf node
    start_Index = int((n / 2)) - 1
    for i in range(start_Index, -1, -1):
        heapify(arr, n, i)
    return arr
#the time complexty is O(n) and auxlially space is O(1)




