import unittest
import Question2


class MyTestCase(unittest.TestCase):
    def test_create_Heap(self):
        test=Question2.create_Heap([20,18,10,12,9,9,3,5,6,8])
        self.assertListEqual(test,[3, 5, 9, 6, 8, 20, 10, 12, 18, 9])

    def test_create_Heap1(self):
        test=Question2.create_Heap([1, 2, 3, 4, 5, 6, 7 ])
        self.assertListEqual(test,[1, 2, 3, 4, 5, 6, 7 ])

    def test_create_Heap2(self):
        test=Question2.create_Heap([1])
        self.assertListEqual(test,[1])



if __name__ == '__main__':
    unittest.main()
