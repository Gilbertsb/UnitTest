import unittest
import Question4


class MyTestCase(unittest.TestCase):
    def test_heapSort(self):
        test=Question4.heapSort([12, 11, 13, 5, 6, 7])
        self.assertListEqual(test,[5, 6, 7, 11, 12, 13])

    def test_heapSort1(self):
        test=Question4.heapSort([20,18,10,12,9,9,3,5,6,8])
        self.assertListEqual(test,[3, 5, 9, 6, 8, 20, 10, 12, 18, 9])


if __name__ == '__main__':
    unittest.main()
