from heapq import *
def heapSort(arr):
    n = len(arr)
    # Building a heap.
    for i in range(n // 2 - 1, -1, -1):
        heapify(arr)

        # One by one trying to extract elements
    for i in range(n - 1, 0, -1):
        arr[i], arr[0] = arr[0], arr[i]  # swap
        heapify(arr)
    return arr



#the time complexty is O(n) and auxlially space is O(1)

