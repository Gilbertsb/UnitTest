import unittest
import Question1


class MyTestCase(unittest.TestCase):
    def test_check_minheap(self):
        test=Question1.check_minheap([])
        self.assertFalse(test, False)

    def test_check_minheap0(self):
        test=Question1.check_minheap([1, 2, 3, 4, 5, 6])
        self.assertTrue(test,True)

    def test_check_minheap1(self):
        test = Question1.check_minheap([90, 15, 10, 7, 12, 2, 7, 3])
        self.assertFalse(test, False)


if __name__ == '__main__':
    unittest.main()
