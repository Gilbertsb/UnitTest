from heapq import *
class Heap:
    heap=[20,18,10,12,9,9,3,5,6,8]
    heapify(heap)

    def GetMinimum(self):
        n=len(self.heap)
        minElem = self.heap[n // 2]
        for i in range(1 + n // 2, n):
            minElem = min(minElem,self.heap[i])
        return minElem
    def ExtractMinimum(self):

        n=len(self.heap)
        minElem = self.heap[n // 2]

        for i in range(1 + n // 2, n):
            minElem = min(minElem,self.heap[i])
        return self.heap.remove(minElem)


    def insert(self,val):
        return self.heap.insert(len(self.heap),val)


    def Delete(self,index):

        return self.heap.pop(index)


run=Heap()


#the time complexty for Get and Extract  is O(n) and for insert and delete is O(1)
# and auxlially space is O(1) for All