#Node class
class Node:
    def __init__(self, itemes):
        self.itemes = itemes
        self.next = None
#Stack class
class Stack:
    # Init method
    def __init__(self):
        self.head = None

    # Method to check if the Stack is empty
    def isempty(self):
        if self.head == None:
            return True
        else:
            return False

    # Method to add element on the queue
    def push(self, itemes):

        if self.head == None:
            self.head = Node(itemes)
        else:
            newnode = Node(itemes)
            newnode.next = self.head
            self.head = newnode
#Method to delete the first element form the stack
    def pop(self):
        if self.isempty():
            return None
        else:
            poppednode = self.head
            self.head = self.head.next
            poppednode.next = None
            return poppednode.itemes
#Method to get the first element from the stack
    def peek(self):
        if self.isempty():
            return None
        else:
            return self.head.itemes

#Method that display all elements in the Stack
    def display(self):
        liststack=[]
        iternode = self.head
        if self.isempty():
            print("Stack EMTY")
        else:
            while (iternode != None):
                liststack.append(iternode.itemes)
                iternode = iternode.next
            print(liststack)




stack = Stack()
print("Is stack empty? ",stack.isempty())
print("**************************")
stack.push(11)
stack.push(22)
stack.push(33)
stack.push(44)
stack.display()

print("\n")
print(stack.peek()," is the first item")
stack.pop()
stack.display()
print("\n")
print(stack.peek()," is the first item now")
print("**************************")
print("Is stack empty? ",stack.isempty())