import gc
#Class Node
class Node:

#Method with Previose and Next
    def __init__(self, items):
        self.items = items
        self.next = None
        self.prev = None
#Class DoublyLinkedList
class DoublyLinkedList:
    def __init__(self):
        self.head = None
#Mehtod to insert elements
    def Insertnode(self, new_item):
        new_node = Node(new_item)
        new_node.next = self.head
        if self.head is not None:
            self.head.prev = new_node
        self.head = new_node
#Method to delet elements from the front
    def deletenode(self, delete):
        if self.head is None or delete is None:
            return
        if self.head == delete:
            self.head = delete.next
        if delete.next is not None:
            delete.next.prev = delete.prev
        if delete.prev is not None:
            delete.prev.next = delete.next
        gc.collect()

#Method that display all element from list
    def displayList(self, node):
        listdobly=[]
        while (node is not None):
            listdobly.append(node.items)
            node = node.next
        print(listdobly)


listobje = DoublyLinkedList()


listobje.Insertnode(2)
listobje.Insertnode(4)
listobje.Insertnode(8)
listobje.Insertnode(10)
listobje.displayList(listobje.head)

listobje.deletenode(listobje.head)
listobje.deletenode(listobje.head.next)
print("After deleting")
listobje.displayList(listobje.head)
