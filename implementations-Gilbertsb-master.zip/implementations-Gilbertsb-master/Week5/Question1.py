#Node class
class Node:
    def __init__(self,items):
        self.items=items
        self.next=None
#Singly linked list
class SinglyLinkedLst:
    def __init__(self):
        self.head=None
#Method to append
    def append(self,items):
        nwnode=Node(items)
        if self.head is None:
            self.head=nwnode
            return
        lstnode=self.head
        while lstnode.next:
            lstnode=lstnode.next
        lstnode.next=nwnode

#Method to prepend
    def prepend(self,items):
        nwnode=Node(items)
        nwnode.next=self.head
        self.head=nwnode
#Method to delete fist element
    def popfirst(self):
        if self.head==None:
            return False
        self.head=self.head.next
#Method that display all elements form list
    def disply(self):
        listsin=[]
        allnodes=self.head
        while allnodes:
            listsin.append(allnodes.items)
            allnodes=allnodes.next
        print(listsin)


linkedlst=SinglyLinkedLst()
linkedlst.append(1)
linkedlst.append(2)
linkedlst.append(3)
linkedlst.append(4)
print("Before we insert element at the first place")
linkedlst.disply()
linkedlst.prepend(7)
print("After we insert at the first element")
linkedlst.disply()
linkedlst.popfirst()
print("after  we pop the first element")
linkedlst.disply()

