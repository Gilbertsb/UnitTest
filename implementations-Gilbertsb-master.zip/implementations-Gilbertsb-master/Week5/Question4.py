
#Node class
class Node:
#Init method
    def __init__(self, items):
        self.items = items
        self.next = None
#Queue class
class Queue:
    # Init method
    def __init__(self):
        self.first = self.itm = None
# Method to check if the Queue is empty
    def isEmpty(self):
        return self.first == None
#Method to add element on the queue
    def EnQueue(self, item):
        temp = Node(item)

        if self.itm == None:
            self.first = self.itm = temp
            return
        self.itm.next = temp
        self.itm = temp

    # Method to delete first element from the queue
    def DeQueue(self):

        if self.isEmpty():
            return
        temp = self.first
        self.first = temp.next

        if (self.first == None):
            self.itm = None
        #Method that display all element from the queue
    def display(self):
        listque=[]
        iternode = self.first
        if self.isEmpty():
            print("Queue is empty")
        else:
            while (iternode != None):
                listque.append(iternode.items)
                iternode = iternode.next
            print(listque)




if __name__ == '__main__':

    queue = Queue()
    print("Is Queue empty? ", queue.isEmpty())
    print("**************************")
    queue.EnQueue(10)
    queue.EnQueue(20)
    queue.display()
    queue.DeQueue()
    queue.EnQueue(30)
    queue.EnQueue(40)
    queue.EnQueue(50)
    print("\n")
    queue.display()
    print("\n")
    print("First element is " + str(queue.first.items))
    print("\n")
    print("**************************")
    print("Is Queue empty? ", queue.isEmpty())
