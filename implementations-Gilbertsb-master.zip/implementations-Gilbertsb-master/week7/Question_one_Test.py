import unittest
import Question_one


class MyTestCase(unittest.TestCase):
    def test_search(self):
        test=Question_one.search([1,2,3,4,5,6,7,8],6)
        self.assertTrue(test,True)
    def test_search1(self):
        test1 = Question_one.search([1,2,3,4,5,6,7,8],12)
        self.assertFalse(test1,False)
    def test_search2(self):
        test1 = Question_one.search([],12)
        self.assertFalse(test1,False)
    def test_search3(self):
        test1 = Question_one.search([1,2,3,4,5,6,7,8],None)
        self.assertFalse(test1,False)


if __name__ == '__main__':
    unittest.main()
