import unittest
import Question_three

class MyTestCase(unittest.TestCase):
    def test_insertion_sort(self):
        test=Question_three.insertion_Sort([8,7,8,7,5,6,6,4,5,3,4,3])
        ans=[3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8]
        self.assertEqual(test,ans)
    def test_insertion_sort2(self):
        test=Question_three.insertion_Sort([8])
        ans=[8]
        self.assertEqual(test,ans)
    def test_insertion_sort3(self):
        test=Question_three.insertion_Sort([])
        ans=[]
        self.assertEqual(test,ans)
    def test_bubble_sort(self):
        test=Question_three.insertion_Sort([12, 11, 13, 5, 6,4,4,4])
        ans=[4, 4, 4, 5, 6, 11, 12, 13]
        self.assertEqual(test,ans)
    def test_bubble_sort2(self):
        test=Question_three.insertion_Sort([4])
        ans=[4]
        self.assertEqual(test,ans)
    def test_bubble_sort3(self):
        test=Question_three.insertion_Sort([])
        ans=[]
        self.assertEqual(test,ans)



if __name__ == '__main__':
    unittest.main()
