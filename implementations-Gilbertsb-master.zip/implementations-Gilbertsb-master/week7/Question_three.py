def insertion_Sort(unsorted_arr):

    for i in range(1, len(unsorted_arr)):#looping through unsorted array
        key = unsorted_arr[i]        #Selcting the first unsorted eleement
        j = i - 1
        while j >= 0 and key < unsorted_arr[j]: #Loop to keep shifting element to right
            unsorted_arr[j + 1] = unsorted_arr[j]
            j -= 1
        unsorted_arr[j + 1] = key #This is here to place unsorted element to correct postion
    return unsorted_arr
###################################################################
def bubble_Sort(arr):

    for i in range(len(arr)):#looping through entire array
        for j in range(len(arr)-1):
            if arr[j] > arr[j + 1]: #Compare two elements of array and if there are not in correct order
                arr[j], arr[j + 1] = arr[j + 1], arr[j] #Swap them

    return arr

print(bubble_Sort([8,7,8,7,5,6,6,4,5,3,4,3]))
print(insertion_Sort([12, 11, 13, 5, 6,4,4,4]))
