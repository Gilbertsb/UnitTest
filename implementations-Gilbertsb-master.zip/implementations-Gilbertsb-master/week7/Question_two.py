def specialsort(associative_arr):
    Two_Darray=[] #empty Array
    for x, y in associative_arr.items(): #looping through associative_arr
        Two_Darray.append([x, y])      #adding both keys and values to 2D array
    Two_Darray.sort(key=lambda x: x[0]) #sorting key which is at index [0]
    Two_Darray.sort(key=lambda y: y[1]) #sorting values which is at index [1]
    dic={}
    for x in range(len(Two_Darray)):
        dic[Two_Darray[x][0]] = Two_Darray[x][1] #appending back what elements to Dictionary

    return dic

print(specialsort({'1':2,'2':3,'3':4,'4':6,'5':6,'6':3,'7':2,'8':4,'9':3}))