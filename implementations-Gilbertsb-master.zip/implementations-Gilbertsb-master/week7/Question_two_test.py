import unittest
import Question_two


class MyTestCase(unittest.TestCase):
    def test_specialsort(self):
        test=Question_two.specialsort({'1':2,'2':3,'3':4,'4':6,'5':6,'6':3,'7':2,'8':4,'9':3})
        answer={'1': 2, '7': 2, '2': 3, '6': 3, '9': 3, '3': 4, '8': 4, '4': 6, '5': 6}
        self.assertDictEqual(test,answer)

    def test_specialsort2(self):
        test = Question_two.specialsort({})
        answer = {}
        self.assertDictEqual(test, answer)

    def test_specialsort3(self):
        test = Question_two.specialsort({'3': 4})
        answer = {'3': 4}
        self.assertDictEqual(test, answer)


if __name__ == '__main__':
    unittest.main()
