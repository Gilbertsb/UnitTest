def search(arr, x):
    try:#Try this instructions below
        for i in arr:
            if arr[i] == x: #if any element of arr equal to x return True
                return True
    except:# In case we are getting retrun False
        return False
# print(search([1,2,3,4,5,6,7,8],6))