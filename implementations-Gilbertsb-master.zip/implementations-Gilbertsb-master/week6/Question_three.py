def fibonnac_sreis(n):
    if n <= 1:    #Base case
        return n
    else:
        return (fibonnac_sreis(n - 1) + fibonnac_sreis(n - 2))   #calcluating Fibbonacc

print(fibonnac_sreis(7))


# time complexity is O(2^n).
