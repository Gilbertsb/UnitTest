def GCD(a, b):
    if a == 0:  # base case
        return b
    return GCD(b % a, a)  #Calculating GCD
print(GCD(-1,15))