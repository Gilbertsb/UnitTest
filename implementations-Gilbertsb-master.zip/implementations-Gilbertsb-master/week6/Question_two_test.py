import unittest
import Question_two


class MyTestCase(unittest.TestCase):
    def test_GSD(self):
        test=Question_two.GCD(1,21)
        ans=1
        self.assertEqual(test,ans)
    def test_GSD2(self):
        test=Question_two.GCD(0,21)
        ans=21
        self.assertEqual(test,ans)
    def test_GSD3(self):
        test=Question_two.GCD(10,15)
        ans=5
        self.assertEqual(test,ans)



if __name__ == '__main__':
    unittest.main()
