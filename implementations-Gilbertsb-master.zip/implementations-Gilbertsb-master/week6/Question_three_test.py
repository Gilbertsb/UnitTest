import unittest
import Question_three

class MyTestCase(unittest.TestCase):
    def test_fibonnac(self):
        test=Question_three.fibonnac_sreis(1)
        ans=1
        self.assertEqual(test,ans)
    def test_fibonnac2(self):
        test=Question_three.fibonnac_sreis(-56)
        ans=-56
        self.assertEqual(test,ans)
    def test_fibonnac3(self):
        test=Question_three.fibonnac_sreis(7)
        ans=13
        self.assertEqual(test,ans)


if __name__ == '__main__':
    unittest.main()
